<?php
//header('Content-Type: application/json');



$ch = curl_init();


curl_setopt($ch, CURLOPT_URL, "https://balneabilidade.ima.sc.gov.br/relatorio/historico");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,"municipioID=23&localID=39&ano=2018&redirect=true");
curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);

$conteudo = curl_exec ($ch);
// echo $conteudo;

$doc =new DOMDocument();

$doc->loadHTML($conteudo);


$tables = $doc->getElementsByTagName('table');
echo '<pre>';


foreach ($tables as $tabela) {

		$tabelas[]  = $tabela;
}

$pontos = [];
$dados =[];

	for ($i=1; $i < count($tabelas) ; $i++) { 
		if (($i%2)){

			$pontos [] = $tabelas[$i];

		}else {
			$pontos [] = $tabelas[$i];
		}
	}

$dado =[];

foreach ($dado as $resultado) {
		# code...
	}	

	var_dump($resultado);
 ?>
